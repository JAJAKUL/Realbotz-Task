import React, { useEffect, useState } from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';
import '../node_modules/bootstrap-icons/font/bootstrap-icons.css';
import './assets/css/App.css';


import data from './data/product'
function App() {

  console.log('=======================', data)
  const [getData, setGetData] = useState([]);
  const [cartData, setCartData] = useState([]);


  useEffect(()=>{
    setGetData(data); // set data in getData state from ./data/product
  },[])

  // function are used for item to add cart and remove from the listed item array
  const handleAddToCart = async (event) => { 

    setCartData([...cartData, event]); // set cartData array

    let arr = getData.filter(e => e !== event); // remove from matched item from existing product list array
    
    setGetData(arr) 

  };

  const handleRemoveToCart = async (event) => {

    setGetData([...getData, event]);

    let arr = cartData.filter(e => e !== event); 
    
    setCartData(arr)
  };

  return (
  <>




<section className="viewReportWrapper cmn-padd-top-70 cmn-padd-bottom-70">
  <div className="container">
      <h2 style={{textAlign: "center"}}>Product Card</h2>
      <div className="row">
        <div className="col-lg-8">

  
      <div className="row">
        
          {
            getData?.length ? <>
             {getData.map( obj => {
                  return <>
                      <div className="col-lg-6">
                        <div className="card">
                          <img src={require(`${obj.image}`)}  style={{width: '100%', height: '175px'}} />
                          
                          <h3>{obj.name}</h3>
                          <p className="price">${obj.price}</p>
                          <p>{obj.description}</p>
                          <p><button onClick={(e)=>handleAddToCart(obj)}>Add to Cart</button></p>
                        </div>
                      </div>
                    </>
                  })}
            </>
            : <>
            <h3 style={{textAlign:'center'}}>No Data Found!!!</h3>
            </>
          }
         
         
      </div>
      </div>
      <div className="col-lg-4">
        <h3 style={{textAlign: 'center', paddingBottom:'10px'}}>Cart List</h3>
        { cartData?.length ? <>
          {cartData.map(obj =>{
            return <>
                 <div className="row">
          
                 <div className="col-lg-3">
                 <img src={require(`${obj.image}`)} style={{width:'65px', height:'55px'}} />
                 </div>
                 <div className="col-lg-7">
                             <p>{obj.name}</p>
                             <span>${obj.price}</span>
                 </div>
                 <div className="col-lg-2"> 
                 <button onClick={(e)=>handleRemoveToCart(obj)}>Remove</button>
                 </div>
                 
     
               
             </div>
             </>
          })}
        
        </>: <>
        <h4 style={{textAlign:'center'}}>No Cart Data Found!!!</h4>
        </>}
   
      </div>

      </div>

  </div>




</section>

  </>
  );
}

export default App;
